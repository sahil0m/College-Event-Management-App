package com.example.eventdeeds;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class frontActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front);  // Your front activity layout

        // Find buttons by ID
        Button signupButton = findViewById(R.id.signup_button);
        Button loginButton = findViewById(R.id.login_button);

        // Set OnClickListener for Signup Button
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start SignupActivity
                Intent signupIntent = new Intent(frontActivity.this, SignupActivity.class);
                startActivity(signupIntent);
            }
        });

        // Set OnClickListener for Login Button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start LoginActivity
                Intent loginIntent = new Intent(frontActivity.this, LoginActivity.class);
                startActivity(loginIntent);
            }
        });
    }
}

package com.example.eventdeeds;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SearchEventActivity extends AppCompatActivity {

    Button cbtn1, cbtn2, cbtn3, cbtn4, cbtn5;

    LinearLayout eventContainer;
    View[] eventCards;
    TextView[] eventTitles;
    EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_event);

        // Bottom Navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                startActivity(new Intent(SearchEventActivity.this, Home_page.class));
                return true;
            } else if (itemId == R.id.nav_search) {
                return true;
            } else if (itemId == R.id.nav_events) {
                startActivity(new Intent(SearchEventActivity.this, AddEventActivity.class));
                return true;
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(SearchEventActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });

        // Buttons
        cbtn1 = findViewById(R.id.cbtn1);
        cbtn2 = findViewById(R.id.cbtn2);
        cbtn3 = findViewById(R.id.cbtn3);
        cbtn4 = findViewById(R.id.cbtn4);
        cbtn5 = findViewById(R.id.cbtn5);

        View.OnClickListener formClickListener = v -> startActivity(new Intent(SearchEventActivity.this, FormActivity.class));
        cbtn1.setOnClickListener(formClickListener);
        cbtn2.setOnClickListener(formClickListener);
        cbtn3.setOnClickListener(formClickListener);
        cbtn4.setOnClickListener(formClickListener);
        cbtn5.setOnClickListener(formClickListener);

        // Search
        searchEditText = findViewById(R.id.searchEditText);

        // Container that holds all cards
        eventContainer = findViewById(R.id.eventContainer);

        // Initialize event cards and titles
        eventCards = new View[] {
                findViewById(R.id.eventCard1),
                findViewById(R.id.eventCard2),
                findViewById(R.id.eventCard3),
                findViewById(R.id.eventCard4),
                findViewById(R.id.eventCard5),
        };

        eventTitles = new TextView[] {
                findViewById(R.id.eventTitle1),
                findViewById(R.id.eventTitle2),
                findViewById(R.id.eventTitle3),
                findViewById(R.id.eventTitle4),
                findViewById(R.id.eventTitle5),
        };

        // Search Functionality
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().toLowerCase();

                eventContainer.removeAllViews();

                // First add matching cards
                for (int i = 0; i < eventTitles.length; i++) {
                    if (eventTitles[i].getText().toString().toLowerCase().contains(query)) {
                        eventContainer.addView(eventCards[i]);
                    }
                }

                // Then add non-matching cards
                for (int i = 0; i < eventTitles.length; i++) {
                    if (!eventTitles[i].getText().toString().toLowerCase().contains(query)) {
                        eventContainer.addView(eventCards[i]);
                    }
                }
            }
        });
    }
}
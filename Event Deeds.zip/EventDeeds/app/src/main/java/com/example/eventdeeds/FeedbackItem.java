package com.example.eventdeeds;
public class FeedbackItem {
    private String userName;
    private String feedbackText;
    private int likeCount;
    private boolean isLiked;

    public FeedbackItem(String userName, String feedbackText, int likeCount) {
        this.userName = userName;
        this.feedbackText = feedbackText;
        this.likeCount = likeCount;
        this.isLiked = false;
    }

    public String getUserName() {
        return userName;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public int getLikeCount() {
        return likeCount;
    }
    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public boolean isLiked() {
        return isLiked;
    }

    public void setLiked(boolean liked) {
        isLiked = liked;
    }
}

package com.example.eventdeeds;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FirstFrontActivity extends AppCompatActivity {

    Button getStartedButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_front); // Make sure your XML is named activity_main.xml

        getStartedButton = findViewById(R.id.getStartedButton);

        getStartedButton.setOnClickListener(view -> {
            Intent intent = new Intent(FirstFrontActivity.this, frontActivity.class); // ✅ Make sure the class name is capitalized properly
            startActivity(intent);
        });
    }
}

package com.example.eventdeeds;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class FeedbackActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FeedbackAdapter adapter;
    private List<FeedbackItem> feedbackList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recyclerViewFeedback);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        feedbackList = new ArrayList<>();

        // Setup the adapter
        adapter = new FeedbackAdapter(feedbackList);
        recyclerView.setAdapter(adapter);

        // Floating Action Button to show feedback dialog
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showFeedbackDialog());

        // Initialize the BottomNavigationView
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // Set listener for navigation item selection
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                // Handle each item selection with if-else
                if (item.getItemId() == R.id.nav_home) {
                    Intent searchIntent = new Intent(FeedbackActivity.this, Home_page.class);
                    startActivity(searchIntent);
                    return true;
                } else if (item.getItemId() == R.id.nav_search) {
                    // Navigate to Search Event page
                    Intent searchIntent = new Intent(FeedbackActivity.this, SearchEventActivity.class);
                    startActivity(searchIntent);
                    return true;
                } else if (item.getItemId() == R.id.nav_events) {
                    // Navigate to Add Event page
                    Intent addEventIntent = new Intent(FeedbackActivity.this, AddEventActivity.class);
                    startActivity(addEventIntent);
                    return true;
                } else if (item.getItemId() == R.id.nav_profile) {
                    // Navigate to Profile page
                    Intent profileIntent = new Intent(FeedbackActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    return true;
                }
                return false;
            }
        });
    }

    // Show the feedback dialog
    private void showFeedbackDialog() {
        // Inflate dialog layout
        View dialogView = LayoutInflater.from(this).inflate(R.layout.activity_dialog_add_feedabck, null);

        EditText editTextFeedback = dialogView.findViewById(R.id.edit_text_feedback);
        RatingBar ratingBar = dialogView.findViewById(R.id.rating_bar);
        Button btnCancel = dialogView.findViewById(R.id.button_cancel);
        Button btnSubmit = dialogView.findViewById(R.id.button_submit);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSubmit.setOnClickListener(v -> {
            String feedback = editTextFeedback.getText().toString().trim();
            float rating = ratingBar.getRating();

            if (!feedback.isEmpty()) {
                FeedbackItem item = new FeedbackItem("Anonymous", feedback, 0); // Default user name & 0 likes
                feedbackList.add(0, item); // Add to top
                adapter.notifyItemInserted(0);
                recyclerView.scrollToPosition(0);
                dialog.dismiss();
            } else {
                editTextFeedback.setError("Please enter feedback");
            }
        });

        dialog.show();
    }
}

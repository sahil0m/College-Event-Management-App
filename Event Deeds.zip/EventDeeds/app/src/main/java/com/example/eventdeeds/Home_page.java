package com.example.eventdeeds;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Home_page extends AppCompatActivity {

    Button btn1, btn2, btn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // Initialize the BottomNavigationView
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // Set listener for navigation item selection
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                if (item.getItemId() == R.id.nav_home) {
                    // Stay on current page
                    return true;
                } else if (item.getItemId() == R.id.nav_search) {
                    Intent searchIntent = new Intent(Home_page.this, SearchEventActivity.class);
                    startActivity(searchIntent);
                    return true;
                } else if (item.getItemId() == R.id.nav_events) {
                    Intent addEventIntent = new Intent(Home_page.this, AddEventActivity.class);
                    startActivity(addEventIntent);
                    return true;
                } else if (item.getItemId() == R.id.nav_profile) {
                    Intent profileIntent = new Intent(Home_page.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    return true;
                }
                return false;
            }
        });

        // Initialize the three buttons
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);

        // Set click listeners to open FormActivity
        View.OnClickListener formClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent formIntent = new Intent(Home_page.this, FormActivity.class);
                startActivity(formIntent);
            }
        };

        btn1.setOnClickListener(formClickListener);
        btn2.setOnClickListener(formClickListener);
        btn3.setOnClickListener(formClickListener);
    }
}

package com.example.eventdeeds;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FormActivity extends AppCompatActivity {

    Button sbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form); // ✅ Ensure layout exists

        // Initialize BottomNavigationView
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // Set listener using if-else
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(FormActivity.this, Home_page.class));
                    return true;
                } else if (itemId == R.id.nav_search) {
                    startActivity(new Intent(FormActivity.this, SearchEventActivity.class));
                    return true;

                } else if (itemId == R.id.nav_events) {
                    startActivity(new Intent(FormActivity.this, AddEventActivity.class));

                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(FormActivity.this, ProfileActivity.class));
                    return true;
                }

                return false;
            }
        });

        // Initialize the buttons
        sbtn = findViewById(R.id.sbtn);


        // Set click listeners to open FormActivity
        View.OnClickListener formClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FormActivity.this, FormActivity.class));
            }
        };

        sbtn.setOnClickListener(formClickListener);

    }
}
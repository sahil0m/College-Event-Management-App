package com.example.eventdeeds;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.FeedbackViewHolder> {

    private final List<FeedbackItem> feedbackList;

    public FeedbackAdapter(List<FeedbackItem> feedbackList) {
        this.feedbackList = feedbackList;
    }

    @NonNull
    @Override
    public FeedbackViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_feedback, parent, false);
        return new FeedbackViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedbackViewHolder holder, int position) {
        FeedbackItem item = feedbackList.get(position);
        holder.userName.setText(item.getUserName());
        holder.feedbackText.setText(item.getFeedbackText());
        holder.likeCount.setText(String.valueOf(item.getLikeCount()));

        // Set heart icon based on liked state
        if (item.isLiked()) {
            holder.likeIcon.setImageResource(R.drawable.ic_heart_filled);
        } else {
            holder.likeIcon.setImageResource(R.drawable.ic_heart);
        }

        // Handle like toggle
        holder.likeIcon.setOnClickListener(v -> {
            if (item.isLiked()) {
                item.setLiked(false);
                item.setLikeCount(item.getLikeCount() - 1);
                holder.likeIcon.setImageResource(R.drawable.ic_heart);
            } else {
                item.setLiked(true);
                item.setLikeCount(item.getLikeCount() + 1);
                holder.likeIcon.setImageResource(R.drawable.ic_heart_filled);
            }
            holder.likeCount.setText(String.valueOf(item.getLikeCount()));
        });
    }

    @Override
    public int getItemCount() {
        return feedbackList.size();
    }

    public static class FeedbackViewHolder extends RecyclerView.ViewHolder {
        TextView userName, feedbackText, likeCount;
        ImageView likeIcon;

        public FeedbackViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.text_user_name);
            feedbackText = itemView.findViewById(R.id.text_feedback);
            likeCount = itemView.findViewById(R.id.text_likes);
            likeIcon = itemView.findViewById(R.id.image_like);
        }
    }
}

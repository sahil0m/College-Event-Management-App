package com.example.eventdeeds;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvUsername;
    private TextView tvEmail;
    private MaterialButton btnLogout;
    private MaterialButton btnFeedback;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize views
        tvUsername = findViewById(R.id.tvUsername);
        tvEmail = findViewById(R.id.tvEmail);
        btnLogout = findViewById(R.id.btnLogout);
        btnFeedback = findViewById(R.id.btnFeedback);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set up bottom navigation
        setupBottomNavigation();

        // Load user data
        loadUserData();

        // Set up logout button
        btnLogout.setOnClickListener(v -> logout());

        // Set up feedback button
        btnFeedback.setOnClickListener(v -> openFeedbackPage());
    }

    private void openFeedbackPage() {
        Intent intent = new Intent(ProfileActivity.this, FeedbackActivity.class);
        startActivity(intent);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.nav_home) {
                    startActivity(new Intent(ProfileActivity.this, Home_page.class));
                    return true;
                } else if (item.getItemId() == R.id.nav_search) {
                    startActivity(new Intent(ProfileActivity.this, SearchEventActivity.class));
                    return true;
                } else if (item.getItemId() == R.id.nav_events) {
                    startActivity(new Intent(ProfileActivity.this, AddEventActivity.class));
                    return true;
                } else if (item.getItemId() == R.id.nav_profile) {
                    return true;
                }
                return false;
            }
        });
    }

    private void loadUserData() {
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE); // Match SignupActivity
        String name = prefs.getString("name", "Lorem ipsum");
        String email = prefs.getString("email", "abc@gmail.com");

        tvUsername.setText(name);
        tvEmail.setText("mail - " + email);
    }

    private void logout() {
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE); // Match SignupActivity
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.apply();

        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
